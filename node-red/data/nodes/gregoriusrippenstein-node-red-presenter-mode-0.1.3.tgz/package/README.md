# Node-RED version 5 Presenter Mode

## Presenter Mode

Provides an action to remove all navigation and sidebars, leaving only the workspace. 

The action can be bound to a keys stroke for easy access.

- `Presenter Mode Toggle`

See [forum](https://discourse.nodered.org/t/nr5-presenter-mode/101334).

## Sidebar panel navigation

Adds `<` `>` and `X` to the sidebar panels for navigation the sidebar panels and closing them again.

See [forum](https://discourse.nodered.org/t/nr5-add-sidebar-panel-controls/101552).

## Hide right sidebar when searching

Fade out the right sidebar when searching for something. This prevents the side bar from hiding any nodes that might have been found but that are located under the sidebar.

See [forum](https://discourse.nodered.org/t/node-red-5-now-available/101239/91?u=gregorius).

## Scrollbars are hidden after 1.5 seconds of inactivity

The scrollbars are hidden automatically after 1.5 seconds because I don't use them! They come back if the workspace is moved.

See [forum](https://discourse.nodered.org/t/non-transparent-background-needed-for-editor-status-and-horizontal-scroll/101590/5?u=gregorius).

## Allow clicking on the preview node creates selected node

![img](https://cdn.openmindmap.org/content/1793004082876_Screenshot_2026-10-26_at_09.36.05.png)

See [forum](https://discourse.nodered.org/t/nr5-preview-node-creates-new-node/101389) and [GitHub](https://github.com/node-red/node-red/issues/5851).

## Add Safe Triangles to the menu

Prevents the submenus from being hidden if the cursor takes the shortest route to the menu.

See [forum](https://discourse.nodered.org/t/ux-safe-triangles-for-menus-interactions/102058).

## Added delete active tab action

`Delete current workspace` can be assigned to a shortcut to not just hide a flow tab but also delete it.

# Artifacts

This codebase is maintained by a Node-RED [flow](https://flowhub.org/f/83b86eac1a8f5436) that maintains the flowing artifacts: 

- [@ FlowHub.org](https://flowhub.org/f/83b86eac1a8f5436)
- [@ GitHub](https://github.com/gorenje/node-red-presenter-mode)
- [@ Flows.nodered.org](https://flows.nodered.org/node/@gregoriusrippenstein/node-red-presenter-mode)
- [@ NPMjs](https://www.npmjs.com/package/@gregoriusrippenstein/node-red-presenter-mode)